package ca.sheridancollege.kumar319.web.interceptors;

import ca.sheridancollege.kumar319.util.AppConstants;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalTime;

@Component
public class GreetingInterceptor implements HandlerInterceptor {

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response,
                           Object handler, ModelAndView modelAndView) throws Exception {

        if (modelAndView == null) {
            modelAndView = new ModelAndView();
        } else {
            LocalTime time = LocalTime.now();
            int hrs = time.getHour();
            if (hrs >= AppConstants.ZERO_NUMBER && hrs <= AppConstants.GREETING_INTERCEPTOR_TWELVE) {
                modelAndView.addObject(AppConstants.GREETING, AppConstants.GREETING_GOOD_MORNING);
            } else if (hrs > AppConstants.GREETING_INTERCEPTOR_TWELVE && hrs <= AppConstants.GREETING_INTERCEPTOR_SEVENTEEN) {
                modelAndView.addObject(AppConstants.GREETING, AppConstants.GREETING_GOOD_AFTERNOON);
            } else {
                modelAndView.addObject(AppConstants.GREETING, AppConstants.GREETING_GOOD_EVENING);
            }
        }
    }
}