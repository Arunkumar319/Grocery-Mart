package ca.sheridancollege.kumar319.configuration;

import ca.sheridancollege.kumar319.beans.Role;
import ca.sheridancollege.kumar319.repository.UserRepository;
import ca.sheridancollege.kumar319.util.ValidationErrorMessages;
import ca.sheridancollege.kumar319.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class DatabaseRolesSeeder {

    private final UserRoleRepository userRoleRepository;
    private final UserRepository userRepository;

    @Autowired
    public DatabaseRolesSeeder(UserRoleRepository userRoleRepository, UserRepository userRepository) {
        this.userRoleRepository = userRoleRepository;
        this.userRepository = userRepository;
    }

    @PostConstruct
    public void seed() {
        if (this.userRoleRepository.count() == 0) {

            Role admin = new Role();
            admin.setAuthority(ValidationErrorMessages.ROLE_ADMIN);

            Role moderator = new Role();
            moderator.setAuthority(ValidationErrorMessages.ROLE_GUEST);

            Role user = new Role();
            user.setAuthority(ValidationErrorMessages.ROLE_USER);

            this.userRoleRepository.save(admin);
            this.userRoleRepository.save(moderator);
            this.userRoleRepository.save(user);
        }
    }
}
