package ca.sheridancollege.kumar319.service;

import ca.sheridancollege.kumar319.dto.service.OfferServiceModel;

import java.util.List;

public interface OfferService {

    List<OfferServiceModel> findAllOffers();
}
