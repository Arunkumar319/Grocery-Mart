package ca.sheridancollege.kumar319.service;

import ca.sheridancollege.kumar319.dto.service.UserServiceModel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceImplTests {

    @Autowired
    private UserService userService;

    @Test
    public void loadUserByUsername() {
        String userName = "admin";
        UserServiceModel user = userService.findUserByUserName(userName);
        assertEquals(userName, user.getUsername());

    }
}